<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="login.php" method="post">
        <input type="text" name="user" id="user"><br>
        <input type="password" name="senha" id="senha"><br>

        <label for="lembrar">Lembre-se</label>
        <input type="checkbox" name="Lembrar" id="lembrar"><br>
        <button type="submit">Entrar</button>
    </form>
</body>
</html>